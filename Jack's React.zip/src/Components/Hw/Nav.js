import React, { Component } from 'react'

export default class Nav extends Component {
  render() {
    return (
      <div className='flex justify-center items-center w-[30%] p-10 bg-orange-600 text-3xl'>Nav</div>
    )
  }
}
