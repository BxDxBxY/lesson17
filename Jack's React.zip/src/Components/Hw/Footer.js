import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <footer className='flex items-center justify-center p-10 bg-red-900 text-3xl' >Footer</footer>
    )
  }
}

