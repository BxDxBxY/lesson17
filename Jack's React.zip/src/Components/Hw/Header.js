import React, { Component } from 'react'

export default class Header extends Component {
  render() {
    return (
      <div className='flex items-center justify-center bg-purple-500 p-10 text-3xl'>Header</div>
    )
  }
}
